## Source Fit - Coding Exam

This source code is for my job application for Source Fit.
