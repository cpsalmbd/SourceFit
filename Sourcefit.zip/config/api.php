<?php

return [
    'products' => 'https://dummyjson.com/products'
];
