<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(__('Source Fit - Coding Exam')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php if(App::environment('production')): ?>
        <?php
            $files = scandir(public_path()."/build/assets/");
            $css = $files[2];
            $script = $files[3];
        ?>
        <link rel="stylesheet" href="<?php echo e(asset('build/assets')); ?>/<?php echo e($css); ?>">
    <?php endif; ?>
    <?php if(App::environment('local')): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?>
</head>
<body>
    <div id="app"></div>

    <?php if(App::environment('production')): ?>
        <script src="<?php echo e(asset('build/assets')); ?>/<?php echo e($script); ?>" defer></script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PROJECT\Sourcefit\resources\views/home.blade.php ENDPATH**/ ?>